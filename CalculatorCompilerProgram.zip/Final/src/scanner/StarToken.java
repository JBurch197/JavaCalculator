/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanner;

/**
 *
 * @author morell
 */
public class StarToken extends BaseToken {
    
//    public static final StarToken T = new StarToken();
//
//    public static StarToken create() {
//        return T;
//    }

    public StarToken() {
        value = "*";
    }
     
    
}
