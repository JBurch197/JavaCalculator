/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanner;

import parser.Instruction;
import parser.Visitor;

/**
 *
 * @author morell
 */
public class Token extends Instruction implements TokenInterface {

    //-----------------  Member variables -----------------//
    protected Buffer buffer; // The data source for the string
    protected int lineNo; // the line number in the source file
    protected int charPos; // the character position in the source file
    BaseToken base; // Wrapped variable
    //--------------------- Constructors: none -----------------//

    public Token(Buffer b, BaseToken bt) {
        buffer = b;
        lineNo = 0;
        charPos = 1;
        base = bt;
    }

    public Token(BaseToken bt) {
        this(null, bt);
    }

    public String getValue() {
        return base.getValue();
    }

    public void setBase(BaseToken bt) {
        base = bt;
    }

    public BaseToken getBase() {
        return base;
    }

    public void setBuffer(Buffer b) {
        buffer = b;
    }

    public void setLineNo(int n) {
        lineNo = n;
    }

    public void setCharPos(int n) {
        charPos = n;
    }

    public int getCharPos() {
        return charPos;
    }

    public String getFileName() {
        return buffer.fileName;
    }

    public int getLineNo() {
        return lineNo;
    }

    public void setValue(String v) {
        base.value = v;
    }

    public String toString() {
        return base.getValue();
    }

    Token get() {
        buffer.get(); // Toss the operator if it is a single character
        return this;
    }

    @Override
    public BaseToken get(Buffer buffer) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void accept(Visitor v) {
        v.visit(this);
    }

    public Number eval() {
        // the only legitimate call is if the base is an id
        if (base instanceof IdToken) {
            return env.get(base.getValue());
        } else if (base instanceof NumberToken) {
            return ((NumberToken)base).getNumber();
        } else {
            System.err.println("Attempt to evaluate " + base.value + ". Something is messed up!");
        }
        System.exit(2);
        return null;

    }
}
