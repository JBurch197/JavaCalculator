/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanner;

/**
 *
 * @author morell
 */
public class RBraceToken extends BaseToken {
    
//    public static final RBraceToken T = new RBraceToken();
//
//    public static RBraceToken create() {
//        return T;
//    }

    public RBraceToken() {
        value = "}";
    }
    
}
