/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanner;

/**
 *
 * @author morell
 */
interface TokenInterface extends BaseTokenInterface {

    public String getValue();

    void setBase(BaseToken bt);

    BaseToken getBase();

    public void setBuffer(Buffer b);

    public void setLineNo(int n);

    public void setCharPos(int n);

    public int getCharPos();

    public String getFileName();

    public int getLineNo();

    public void setValue(String v);

    public String toString();
    
}
