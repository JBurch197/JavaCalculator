/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanner;

/**
 *
 * @author Jeremy Burch
 */
public class simpleTokenFactory {
    public static BaseToken createToken(String type){
        BaseToken token = null;
        
//        if(type.equals("else")){
//            token = new ElseToken();
//        }
//        else if(type.equals("while")){
//            token = new WhileToken();
//        }
        if(type.equals("-")){
            token = new MinusToken();
        }
        else if(type.equals("+")){
            token = new PlusToken();
        }
        else if(type.equals("*")){
            token = new StarToken();
        }
        else if(type.equals(":")){
            token = new ColonToken();
        }
        else if(type.equals(":=")){
            token = new AssignToken();
        }
        else if(type.equals(",")){
            token = new CommaToken();
        }
        else if(type.equals("\"")){
            token = new DoubleQuoteToken();
        }
        else if(type.equals("=")){
            token = new EqToken();
        }
        else if(type.equals(">=")){
            token = new GeToken();
        }
        else if(type.equals(">")){
            token = new GtToken();
        }
        else if(type.equals("{")){
            token = new LBraceToken();
        }
        else if(type.equals("[")){
            token = new LBracketToken();
        }
        else if(type.equals("(")){
            token = new LParenToken();
        }
        else if(type.equals("<=")){
            token = new LtToken();
        }
        else if(type.equals("}")){
            token = new RBraceToken();
        }
        else if(type.equals("]")){
            token = new RBracketToken();
        }
        else if(type.equals(")")){
            token = new RParenToken();
        }
        else if(type.equals("!=")){
            token = new NeToken();
        }
        else if(type.equals("!")){
            token = new NotToken();
        }
        else if(type.equals("%")){
            token = new PercentToken();
        }
        else if(type.equals(";")){
            token = new SemiToken();
        }
        else if(type.equals("'")){
            token = new SingleQuoteToken();
        }
        else if(type.equals("/")){
            token = new SlashToken();
        }
        else if(type.equals("if")){
            token = new IfToken();
        }
        else if(type.equals("then")){
            token = new ThenToken();
        }
        else if(type.equals("end")){
            token = new EndToken();
        }
        else if(type.equals("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")){
            token = new IdToken();
        }
        else if(type.equals("0123456789")){
            token = new NumberToken();
        }
        else if(type.equals("else")){
            token = new ElseToken();
        }
        else if(type.equals("do")){
            token = new DoToken();
        }
        else if(type.equals("while")){
            token = new WhileToken();
        }
        else if(type.equals("print")){
            token = new PrintToken();
        }
        else if(type.equals("read")){
            token = new ReadToken();
        }
        else if(type.equals("eof")){
            token = new EofToken();
        }
        return token;
    }
}
