/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanner;

/**
 *
 * @author morell
 */
public class LBracketToken extends BaseToken {
    
//    public static final LBracketToken T = new LBracketToken();
//
//    public static LBracketToken create() {
//        return T;
//    }

    public LBracketToken() {
        value = "[";
    }
    
}
