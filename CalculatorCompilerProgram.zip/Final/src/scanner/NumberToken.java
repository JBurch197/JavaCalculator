/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanner;

/**
 *
 * @author morell
 */
import parser.Visitor;
public class NumberToken extends BaseToken {
    
    Number number;

    public NumberToken() {
        value = "0";
        number = 0;
    }

    public NumberToken(String value) {
        this.value = value;
        if (value.contains(".")) {
            this.number = Double.parseDouble(value);
        } else {
            this.number = Integer.parseInt(value);
        }
    }

    public BaseToken get(Buffer buffer) {
        String n = buffer.getNumber();
        NumberToken no = new NumberToken(n);
        return no;
    }

    public String getValue() {
        return value;
    }

    public Number getNumber() {
        return number;
    } 
    
}
