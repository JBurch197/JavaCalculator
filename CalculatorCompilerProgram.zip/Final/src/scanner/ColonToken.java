/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanner;

/**
 *
 * @author morell
 */
public class ColonToken extends BaseToken {
    
//    public static final ColonToken T = new ColonToken();
//
//    public static ColonToken create() {
//        return T;
//    }

    public ColonToken() {
        value = ":";
    }

    public BaseToken get(Buffer buffer) {
        buffer.get();
        if (buffer.peek() == '=') {
            buffer.get();
            return simpleTokenFactory.createToken(":=");
        } else {
            return simpleTokenFactory.createToken(":");
        }
    }
    
}
