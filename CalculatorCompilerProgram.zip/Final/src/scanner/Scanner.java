/*
 * Scanner -- Generic scanner tailored via the Strategy Pattern
 */
package scanner;

/**
 *
 * @author morell
 */
public class Scanner {

    BaseToken[] start;
    Buffer buffer;
    Token t;   // Most recently read token

    public Scanner(Buffer b) {
        start = new BaseToken[128];
        for (int i = 0; i < 128; i++) {
            start[i] = BadToken.create();
        }
        buffer = b;
    }

    /**
     * Associate t with all the characters in chars -- the Strategy Pattern!
     *
     * @param chars
     * @param t
     */
    public void init(String chars, BaseToken t) {
        for (int i = 0; i < chars.length(); i++) {
            start[chars.charAt(i)] = t;
        }
    }

    public Token getCurrentToken() {
        return t;
    }

    public Token get() {
        buffer.skipBlanks();
        if (buffer.eof()) {
            t = new Token(buffer, null);
            t.setBase(simpleTokenFactory.createToken("eof"));
        } else {
            char ch = buffer.peek();

            BaseToken base = start[ch].get(buffer);  // Creates the token and sets its value
            t = new Token(buffer, base);
            t.setLineNo(buffer.lineNumber());
            t.setCharPos(buffer.columnNumber());
            // Set the remaining attributes of the token
            t.setBase(base);
        }
        return t;
    }

    public void reset() {
        buffer.reset();
        get();
    }
}
