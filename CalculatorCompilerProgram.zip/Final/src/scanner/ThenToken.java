/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanner;

/**
 *
 * @author morell
 */
public class ThenToken extends IdToken {
    
//    public static final ThenToken T = new ThenToken();
//
//    public static ThenToken create() {
//        return T;
//    }

    public ThenToken() {
        value = "then";
    }
    
}
