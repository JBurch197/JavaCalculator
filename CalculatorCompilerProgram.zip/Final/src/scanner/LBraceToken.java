/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanner;

/**
 *
 * @author morell
 */
public class LBraceToken extends BaseToken {
    
//    public static final LBraceToken T = new LBraceToken();
//
//    public static LBraceToken create() {
//        return T;
//    }

    public LBraceToken() {
        value = "{";
    }
    
}
