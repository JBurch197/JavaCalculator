package scanner;

import parser.Instruction;
import scanner.GeToken;
import scanner.Buffer;

public class BaseToken implements BaseTokenInterface {

    //-----------------  Member variables -----------------//
    String value;
    //--------------------- Constructors: none -----------------//
    // Setters

    public String toString() {
        return value;
    }
    // Getters

    public String getValue() {
        return value;
    }

    public BaseToken get(Buffer buffer) {
        buffer.get(); // Toss the operator if it is a single character
        return this;
    }

}
