/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanner;

/**
 *
 * @author morell
 */
public class BadToken extends BaseToken {
    
    private BadToken() {
        value = "BadToken";
    }
    static BadToken BAD_TOKEN = null;

    static BaseToken create() {
        if (BAD_TOKEN == null) {
            BAD_TOKEN = new BadToken();
        }
        return BAD_TOKEN;
    }

    BadToken(String chars) {
        value = chars;
    }
    
}
