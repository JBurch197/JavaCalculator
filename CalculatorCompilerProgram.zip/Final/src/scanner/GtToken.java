/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanner;

/**
 *
 * @author morell
 */
public class GtToken extends BaseToken {
    
//    public static final GtToken T = new GtToken();
//
//    public static GtToken create() {
//        return T;
//    }

    public GtToken() {
        value = ">";
    }

    public BaseToken get(Buffer buffer) {
        if (buffer.peek() == '=') {
            buffer.get();
            return simpleTokenFactory.createToken(">=");
        } else {
            return simpleTokenFactory.createToken(">");
        }
    }
    
}
