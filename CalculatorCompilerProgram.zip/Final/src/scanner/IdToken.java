/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanner;

import scanner.*;

/**
 *
 * @author morell
 */
public class IdToken extends BaseToken {

    // Not used ... yet!
    public IdToken() {
        value = "";
    }

    public IdToken(String v) {
        value = v;
    }

    @Override
    public BaseToken get(Buffer buffer) {
        value = buffer.getId();
        switch (value) {
            case "if":
                return simpleTokenFactory.createToken("if");
            case "then":
                return simpleTokenFactory.createToken("then");
            case "else":
                return simpleTokenFactory.createToken("else");
            case "while":
                return simpleTokenFactory.createToken("while");
            case "read":
                return simpleTokenFactory.createToken("read");
            case "print":
                return simpleTokenFactory.createToken("print");
            case "end":
                return simpleTokenFactory.createToken("end");
            case "do":
                return simpleTokenFactory.createToken("do");

        }
        return new IdToken(value);
    }

    public String toString() {
        return value;
    }

}
