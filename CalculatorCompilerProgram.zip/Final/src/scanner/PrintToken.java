/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scanner;

/**
 *
 * @author morell
 */
public class PrintToken extends BaseToken {
    
//    public static final PrintToken T = new PrintToken();
//
//    public static PrintToken create() {
//        return T;
//    }

    public PrintToken() {
        value = "print";
    }
    
}
