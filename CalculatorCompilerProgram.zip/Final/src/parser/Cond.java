/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

/**
 *
 * @author morell
 */
public class Cond extends Instruction {

    Cond(Expression exp) {
        il.add(exp);
    }

    static Cond parse() {
        return new Cond(Expression.parse());
    }
    
    Number eval(){
        Number result = il.get(0).eval();
        return result;
    }
    

    Cond() {
    }

}
