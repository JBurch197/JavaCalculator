/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import scanner.*;

/**
 *
 * @author morell
 */
public class Stmt extends Instruction {

    public static Instruction parse() {
        Token t = scanner.getCurrentToken();
        BaseToken base = t.getBase();
        Instruction stmt = new Stmt();
        if (base instanceof IdToken) {
            stmt.add(Assignment.parse());
        } else if (base instanceof WhileToken) {
            stmt.add(While.parse());
        } else if (base instanceof IfToken) {
            stmt.add(If.parse());
        } else if (base instanceof ReadToken) {
            stmt.add(Read.parse());
        } else if (base instanceof PrintToken) {
            stmt.add(Print.parse());
        }
        else {
            System.err.println("Expected beginning of statement but found " + t);
            System.exit(2);
        }
        return stmt;
    }
    Number eval(){
        il.get(0).eval();
        return null;
    }

    public void accept(Visitor v) {
        v.visit(this);
    }
}
