/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import scanner.DoToken;
import scanner.EndToken;
import scanner.WhileToken;
import scanner.simpleTokenFactory;

/**
 *
 * @author morell
 */
public class While extends Instruction {

    While() {
    }

    While(Cond c, StmtList sl) {
        il.add(c);
        il.add(sl);
    }

    @Override
    public void accept(Visitor v) {
        v.visit(this);
    }

    public static While parse() {
        verify(simpleTokenFactory.createToken("while"));  // Toss the while
        Cond cond = Cond.parse();
        verify(simpleTokenFactory.createToken("do"));
        StmtList stmtlist = StmtList.parse();
        verify(simpleTokenFactory.createToken("end"));
        return new While(cond, stmtlist);
    }
    
    Number eval(){
        Number cond = il.get(0).eval();
        while(!cond.equals(0.0)){
            il.get(1).eval();
            cond = il.get(0).eval();
        }
        String msg = "" + cond;
        notify(msg,this);
        return null;
    }
}
