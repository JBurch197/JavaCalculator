
/*
  PrintVisitor -- Implements the Visitor Pattern for printing a program tree
  For the program constructs it is assumed that abstract syntax is used.
  For example  <if> ::= if <cond> then <stmtlist> else <stmtlist> end
  will store only
        <if>
         |
  .--------------------.
  |        |           |
<cond> <stmtmlist> <stmtlist>

  i.e., inferable tokens are omitted
 */
package parser;

/**
 *
 * @author morell
 */
import scanner.BaseToken;
import scanner.Token;

public class PrintVisitor implements Visitor {

    @Override
    public void visit(Instruction instr) {
        // Do nothing
        System.out.print(instr.getValue());

    }

    @Override
    public void visit(Program instr) {
        instr.il.get(0).accept(this);
    }

    @Override
    public void visit(StmtList instr) {
        for (Instruction stmt : instr.il) {
            visit((Stmt) stmt);
        }
    }
    static int indentation = 0;

    void indent() {
        for (int i = 0; i < 4 * indentation; i++) {
            System.out.append(' ');
        }
    }

    public PrintVisitor() {
    }

    @Override
    public void visit(Stmt instr) {
        instr.il.get(0).accept(this);
    }

    @Override
    public void visit(While instr) {
        indent();
        System.out.print("while ");
        visit((Cond) instr.il.get(0));  // print the cond
        System.out.println(" do ");
        indentation++;
        visit((StmtList) instr.il.get(1)); // print the body
        indentation--;
        indent();
        System.out.println("end");
    }

    @Override
    public void visit(Cond instr) {
        // Temporarily cond is just an expression , no pass through
        visit((Expression) instr.il.get(0));
    }

    @Override
    public void visit(If instr) {
        indent();
        System.out.print("if ");
        visit((Cond) instr.il.get(0));  // print the cond
        System.out.println(" then ");
        indentation++;
        visit((StmtList) instr.il.get(1));  // print the then stmt block
        indentation--;
        if (instr.il.size() > 2) {
            indent();
            System.out.println("else");
            indentation++;
            visit((StmtList) instr.il.get(2));  // print the else stmt block
            indentation--;
        }
        indent();
        System.out.println("end");
    }

    @Override
    public void visit(Read instr) {
        indent();
        System.out.print("read ");
        System.out.println(instr.il.get(0));

        // Future expansion:
//        for (int i = 1; i < instr.il.size(); i++) {
//            System.out.print(", " + instr.il.get(i));
//        }
    }

    @Override
    public void visit(Print instr) {
        indent();
        System.out.print("print ");
        instr.il.get(0).accept(this);
//        for (int i = 1; i < instr.il.size(); i++) {
//            System.out.print(", ");
//            instr.il.get(i).accept(this);
//       
        System.out.println("");
    }

    @Override
    public void visit(Assignment instr) {
        indent();
        instr.il.get(0).accept(this);
        System.out.print(" := ");
        instr.il.get(1).accept(this);
        System.out.println();
    }

    @Override
    public void visit(Expression instr) {
        // A series or <term> {[+-] <term>}
        visit((Term) instr.il.get(0));
        int i = 1;
        while (i < instr.il.size()) {
            System.out.print(instr.il.get(i));    // print the + or -
            i++;
            visit((Term) instr.il.get(i));
            i++;
        }
    }

    @Override
    public void visit(Term instr) {
        // A series or <factor> {[*/] <factor>}
        visit((Factor) instr.il.get(0));
        int i = 1;
        while (i < instr.il.size()) {
            instr.il.get(i).accept(this);
            i++;
            instr.il.get(i).accept(this);
            i++;
        }
    }

    @Override
    public void visit(Factor instr) {
        if (instr.negative) {
            System.out.print("-");
        }
        if (instr.parenthesized) {
            System.out.print("(");
        }
        instr.il.get(0).accept(this);
        if (instr.parenthesized) {
            System.out.print(")");
        }
    }

    @Override
    public void visit(No instr) {

        System.out.print(instr.no);
    }

    @Override
    public void visit(Token instr) {
        BaseToken base = instr.getBase();
        System.out.print(base.getValue());
    }
}
