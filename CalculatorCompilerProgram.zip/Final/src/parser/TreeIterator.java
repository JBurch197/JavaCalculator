/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import java.util.Stack;

/**
 *
 * @author morell
 */
class TreeIterator implements Iterator {
    
    int pos; // Tracks the current child
    Instruction instr; // Tracks the current node
    Stack<StackEntry> stack; // Stack of instructions to the top of the tree

    TreeIterator(Instruction instruction) {
        instr = instruction; // node in the tree
        pos = 0; // set pos to 0 before the start of instrlist .il.
        stack = new Stack<StackEntry>(); // Empty to start
    }

    /**
    Return a reference to the current instruction in the tree
    and advances to the next instruction, either down or up and over
     */
    public Instruction next() {
        Instruction result = instr;
        // Advance to next location
        if (pos < instr.il.size()) {
            // move down the tree if possible
            StackEntry entry = new StackEntry(instr, pos);
            stack.push(entry);
            instr = instr.il.get(0);
            pos = 0;
        } else {
            // move back up
            if (!stack.empty()) {
                do {
                    StackEntry entry = stack.pop();
                    instr = entry.instr;
                    pos = entry.pos + 1;
                } while (pos >= instr.il.size() && !stack.empty());
                if (pos < instr.il.size()) {
                    StackEntry entry = new StackEntry(instr, pos);
                    stack.push(entry);
                    instr = instr.il.get(pos);
                    pos = 0;
                } else {
                    pos = -1;
                    instr = null;
                }
            } else {
                pos = -1;
                instr = null;
            }
        }
        return result;
    }

    public boolean hasNext() {
        if (instr == null) {
            return false;
        }
        return true;
    }
    
}
