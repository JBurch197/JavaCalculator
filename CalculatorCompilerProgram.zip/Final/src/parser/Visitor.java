/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

/**
 *
 * @author morell
 */
import scanner.*;

public interface Visitor {

// There should be one visit() per construct of the language
// (or at least one for each one that needs to be visited
    public void visit(Instruction instr);

    public void visit(Program instr);

    public void visit(StmtList instr);

    public void visit(Stmt instr);

    public void visit(While instr);

    public void visit(If instr);

    public void visit(Read instr);

    public void visit(Print instr);

    public void visit(Assignment instr);

    public void visit(Cond instr);

    public void visit(Expression instr);

    public void visit(Term instr);

    public void visit(Factor instr);

    public void visit(No instr);
    
    public void visit(Token instr);
}
