/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import scanner.*;

/**
 *
 * @author morell
 */
public class StmtList extends Instruction {

    /**
     *
     * @return the parsed statement list
     */
    public static StmtList parse() {
        Token t = scanner.getCurrentToken();
        BaseToken base = t.getBase();
        StmtList stmtlist = new StmtList();
        while (base instanceof IdToken
                || base instanceof WhileToken
                || base instanceof IfToken
                || base instanceof ReadToken
                || base instanceof PrintToken) {
            stmtlist.add(Stmt.parse());
            base = scanner.getCurrentToken().getBase();

        }
        return stmtlist;
    }

    Number eval(){
        for( Instruction instr: il){
            instr.eval();
        }
        return null;
    }

    public void accept(Visitor v) {
        v.visit(this);
    }
}
