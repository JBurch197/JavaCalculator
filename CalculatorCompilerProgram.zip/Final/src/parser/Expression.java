/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import java.util.ArrayList;
import scanner.*;

/**
 *
 * @author morell
 */
public class Expression extends Instruction {

    Expression() {
        value = "Expression";
    }

    Expression(ArrayList<Instruction> instructions) {
        il = instructions;
    }

    @Override
    public void accept(Visitor v) {
        v.visit(this);
    }

    /*
       <exp> :: = <term> { <addop>  <term> }
     */
    static Expression parse() {
        ArrayList<Instruction> exp = new ArrayList<>();
        exp.add(Term.parse());
        Token t = scanner.getCurrentToken();
        while (t.getBase() instanceof PlusToken || t.getBase() instanceof MinusToken) {
            exp.add(t);
            t = scanner.get();  // Prime the pump for parsing a Term
            exp.add(Term.parse());
            t = scanner.getCurrentToken();
        }
        return new Expression(exp);
    }

    Number eval() {
        double result = il.get(0).eval().doubleValue();
        for (int i = 1; i < il.size(); i = i + 2) {
            double value = il.get(i + 1).eval().doubleValue();
            Token t = (Token) (il.get(i));
            BaseToken base = t.getBase();
            if (base instanceof PlusToken) {
                result = result + value;
            } else if (base instanceof MinusToken) {
                result = result - value;
            } else {
                System.err.println("Expecting *+ or - found " + base.getValue());
                System.exit(3);
            }
        }
        return result;

    }
}
