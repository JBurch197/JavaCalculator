/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

/**
 *
 * @author morell
 */
public class Program extends Instruction {

    Program() {
    }

    public Program(Instruction instr) {
        il.add(instr);

    }

    public static Program parse() {
        StmtList stmtlist = StmtList.parse();
        return new Program(stmtlist);
    }
    
    Number eval(){
        il.get(0).eval();
        return null;
    }
    
    @Override
    public void accept(Visitor v) {
        v.visit(this);
    }

}
