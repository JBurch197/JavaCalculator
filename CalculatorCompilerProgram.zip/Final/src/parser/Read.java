/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import java.util.ArrayList;
import scanner.CommaToken;
import scanner.IdToken;
import scanner.ReadToken;
import scanner.Token;
import java.util.Scanner;
import scanner.simpleTokenFactory;

/**
 *
 * @author morell
 */
public class Read extends Instruction {

    Read(Token t) {
        il.add(t);
    }

    public static Read parse() {
        verify(simpleTokenFactory.createToken("read"));
        IdToken id = new IdToken();
        Token t = scanner.getCurrentToken();
        verify(id);
        return new Read(t);
    }
    
    Number eval(){
        Scanner in = new Scanner(System.in);
        int a = in.nextInt();
        env.put(il.get(0).getValue(),a);
        String msg = "" + a;
        notify(msg,this);
        return null;
    }

    @Override
    public void accept(Visitor v) {
        v.visit(this);
    }
}
