/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import scanner.*;

/**
 *
 * @author morell
 */
public class Assignment extends Instruction {

    public Assignment() {
    }

    public Assignment(Token lhs, Expression rhs) {
        il.add(lhs);
        il.add(rhs);
    }

    @Override
    public void accept(Visitor v) {
        v.visit(this);
    }

    static Assignment parse() {
        Token t = scanner.getCurrentToken();

        verify(new IdToken());
        verify(simpleTokenFactory.createToken(":="));
        // scanner.get(); // Prime the pump for parsing the expression
        Expression rhs = Expression.parse();
        return new Assignment(t, rhs);
    }
    
    Number eval(){
        Number value2 = il.get(1).eval();
        env.put(il.get(0).getValue(),value2);
        String msg = "" + value2;
        notify(msg,this);
        return null;
    }
}
