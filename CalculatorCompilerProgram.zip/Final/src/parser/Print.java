/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import scanner.*;

/**
 *
 * @author morell
 */
public class Print extends Instruction {

    public Print(Expression t) {
        il.add(t);
    }

    public static Print parse() {
        verify(simpleTokenFactory.createToken("print"));
        Expression exp = Expression.parse();
        return new Print(exp);
    }
    
    Number eval(){
        Number value = il.get(0).eval();
        String msg = "" + value;
        notify(msg,this);
        return null;
    }

    public void accept(Visitor v) {
        v.visit(this);
    }
}
