/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import scanner.*;

/**
 *
 * @author morell
 */
public class If extends Instruction {

    public If() {
    }

    public If(Cond c, StmtList sl) {
        il.add(c);
        il.add(sl);
    }

    public If(Cond c, StmtList s1, StmtList s2) {
        il.add(c);
        il.add(s1);
        il.add(s2);
    }

    @Override
    public void accept(Visitor v) {
        v.visit(this);
    }

    public static If parse() {
        If ifstmt = null;
        verify(simpleTokenFactory.createToken("if"));

        Cond cond = Cond.parse();
        verify(simpleTokenFactory.createToken("then"));  // Skip the then
        StmtList s1 = StmtList.parse();

        if (scanner.getCurrentToken().getBase() == simpleTokenFactory.createToken("else")) {
            verify(simpleTokenFactory.createToken("else"));
            StmtList s2;

            s2 = StmtList.parse();
//            verify(simpleTokenFactory.createToken("end"));

            return new If(cond, s1, s2);
        }
        verify(simpleTokenFactory.createToken("end"));
        return new If(cond, s1);
    }
 
    Number eval(){
        Number cond = il.get(0).eval();
        if(!cond.equals(0.0) ||!cond.equals(0)){
            il.get(1).eval();
        }
        else{
            il.get(2).eval();
        }
        String msg = "" + cond;
        notify(msg,this);
        return null;
    }
}
