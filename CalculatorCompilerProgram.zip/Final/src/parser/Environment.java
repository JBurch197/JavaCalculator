/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import java.util.HashMap;

/**
 *
 * @author morell
 */
public class Environment {
    private final HashMap<String,Number> env;    
    Environment () {
        env = new HashMap<>();
    }
    public Number get(String id) {
        Number i = env.get(id);
        if (i == null) {
            System.err.println("Variable '" + id +"' does not exist ... exiting");
            System.exit(-1);
        }
        return i;
    }
    public void put (String id, Number val) {
        Number i = val;
        env.put(id,i);
    }
}
