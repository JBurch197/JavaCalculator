/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import java.util.ArrayList;
import scanner.*;

/**
 *
 * @author morell and Burch
 */
public class Main {

    static void testScanner(Scanner scanner) {
        // Setup a buffer 

        Token t = scanner.get();
        while (!(t.getBase() instanceof BadToken) && !(t.getBase() instanceof EofToken)) {
            System.out.println(t.getValue() + " at line " + t.getLineNo() + ", column " + t.getCharPos());
            t = scanner.get();
        }
        if (!(t.getBase() instanceof EofToken)) {
            System.out.println("Error should have been at end of file");
        }
    }

    static Scanner init(String input) {
        Buffer buffer = new Buffer(input);
        Scanner scanner = new Scanner(buffer);

        Instruction.setScanner(scanner);

        scanner.init("0123456789", simpleTokenFactory.createToken("0123456789"));
        scanner.init("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", simpleTokenFactory.createToken("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"));

        scanner.init("(", simpleTokenFactory.createToken("("));
        scanner.init(")", simpleTokenFactory.createToken(")"));
        scanner.init(":", simpleTokenFactory.createToken(":"));
        scanner.init("/", simpleTokenFactory.createToken("/"));
        scanner.init("-", simpleTokenFactory.createToken("-"));
        scanner.init("+", simpleTokenFactory.createToken("+"));
        scanner.init("*", simpleTokenFactory.createToken("*"));
        scanner.init("%", simpleTokenFactory.createToken("%"));
        scanner.init("<", simpleTokenFactory.createToken("<"));
        scanner.init("=", simpleTokenFactory.createToken("="));
        scanner.init("!", simpleTokenFactory.createToken("!"));
        scanner.init(">", simpleTokenFactory.createToken(">"));
        scanner.init("[", simpleTokenFactory.createToken("["));
        scanner.init("]", simpleTokenFactory.createToken("]"));
        scanner.init("{", simpleTokenFactory.createToken("{"));
        scanner.init("}", simpleTokenFactory.createToken("}"));
        scanner.init("(", simpleTokenFactory.createToken("("));
        scanner.init(")", simpleTokenFactory.createToken(")"));
        scanner.init(",", simpleTokenFactory.createToken(","));
        scanner.init(";", simpleTokenFactory.createToken(";"));
        scanner.init("'", simpleTokenFactory.createToken("'"));
        scanner.init("\"",simpleTokenFactory.createToken("\""));
        scanner.get();  // Prime the pump;
        return scanner;
    }

//    static void testFactor(String input) {
//        init(input);
//        Factor factor = Factor.parse();
//        System.out.println("Evaling Factor " + input + ": " + factor.eval());
//    }
//
//    static void testTerm(String input) {
//        init(input);
//        Term term = Term.parse();
//        System.out.println("Evaling Term " + input + ": " + term.eval());
//    }
//
//    static void testExpression(String input) {
//        init(input);
//        Expression exp = Expression.parse();
//        System.out.println("Evaling Expression " + input + ": " + exp.eval());
//    }
//    
//    static void testCond(String input){
//        init(input);
//        Cond cond = Cond.parse();
//        System.out.println("Evaling Cond "+ input + ": " + cond.eval());
//        
//    }
//    
//    static void testAssign(String input){
//        init(input);
//        Assignment assign = Assignment.parse();
//        System.out.println("Evaling Assign "+ input + ": "+ assign.eval());
//    }
//    
    public static void testProgram(String input){
        init(input);
        Program program = Program.parse();
        program.eval();
    }

    
//    
//    public static void register(Observer obs){
//        if(obs = null){
//            obs = ;
//        }
//        
//    }
           
//    notifyAll(){
//        
//    }
       
    static CalGUI gui = new CalGUI();
       
   public static void main(String[] args) {
    java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            gui.setVisible(true);
        }
    });
        Environment env = new Environment();
        Instruction.setEnvironment(env);
//        
//        init("-fff");
//
//         testScanner(scanner);
//         Set up parser
//        PrintVisitor v = new PrintVisitor();
//        /*
//        Factor f = Factor.parse();
//        f.accept(v);
//        System.out.println("");
//        scanner = init("adog := acat");
//
//        Assignment assignment = Assignment.parse();
//        assignment.accept(v);
//
//        scanner = init("akitty := anowl *(( adog / ---+--apig))");
//        assignment = Assignment.parse();
//        assignment.accept(v);
//         */
//        scanner = init("if a then b := c end");
//        If ifstmt = If.parse();
//        ifstmt.accept(v);
//        scanner = init("if a then b := c d := f else a := 1 end");
//        If ifstmt = If.parse();
//        ifstmt.accept(v);
//        scanner = init("a := 5 while a do a := a -1 if a then b := d end end");
//        Program program = Program.parse();
//        program.accept(v);
//        scanner = init("read a print a while a do a := (a - 1 ) if a then print a else print 2*b  end end");
//                Program p = Program.parse();
//        p.accept(v);
//        scanner = init("-17.3");
//        Factor n = Factor.parse();
//        System.out.println("no is " + n.eval());
//
//        System.out.println ("id value is  (expect an error)");
//        Factor id = Factor.parse();
//        System.out.println(id.eval());
//         Set up the referencing environment

//         Put a and b in the referencing environment w/value 10 and 20
//         This allows the testing program to proceed as if two assignments
//         have already been done (a:=10 and b := 20)
//        env.put("a", 10);
//        env.put("b", 20);
//
//         Check the evaluation of a single number
//        
//
//        Factor factor;
//        testFactor("27");
//        testFactor("a");
//        testFactor("b");
//
//        testTerm("-13.7");
//        testTerm("a");
//        testTerm("b");
//        testTerm("a*b");
//        testTerm("a*b/a");
//        
//
//        testExpression("0.5");
//        testExpression("a + b");
//        testExpression("a+b + a*b");
//        testExpression("(a+b)/(b-a)");
//        testExpression("(20-5)/5");
//        testAssign("b := a");
//        testProgram("read a "
//                   + "b := 0 "
//                    + "while a do a:=a-1 print a end "
//                    +  " if b then b:=b+7 print b else print b end");
  }
}
