/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import scanner.*;

/**
 *
 * @author morell
 */
class No extends Instruction {

    Number no;

    No() {
        value = "No";
    }

    No(Number n) {
        no = n;
    }

    @Override
    public void accept(Visitor v) {
        v.visit(this);
    }

    static No parse() {
        Token t = scanner.getCurrentToken();
        Number no = ((NumberToken) t.getBase()).getNumber();
        scanner.get();
        return new No(no);
    }
    
     Number eval() { return no;}

}
