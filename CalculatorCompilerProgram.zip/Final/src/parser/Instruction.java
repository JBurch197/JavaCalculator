package parser;

import java.util.ArrayList;
import scanner.*;

import java.util.Stack;

public class Instruction implements Visitable {
    static protected Scanner scanner;
    static protected Environment env;

    public static void setScanner(Scanner scanner) {
        Instruction.scanner = scanner;
    }

    public static boolean verify(BaseToken base) {
        Token t = scanner.getCurrentToken();
        if (base.getClass().equals(t.getBase().getClass())) {
            scanner.get();
            return true;
        }
        System.err.println("Line " + t.getLineNo() + " Column " + t.getCharPos()
                + ": found" + t + " but expected " + base);
        System.exit(1);
        return false;  // Just to appease NetBeans

    }
    public ArrayList<Instruction> il;
    public String value;

    public Instruction() {
        il = new ArrayList<Instruction>();
    }

    public void add(Instruction i) {
        il.add(i);
    }
      
    static ArrayList<Observer> obs = new ArrayList<>();
    
    public void notify(String msg, Instruction instr){
        Main.gui.update(msg,instr);
    }
    
    public static void register(Observer o){
        obs.add(o);
    }

    String getType() {
        String classname = getClass().toString();
        int pos = classname.lastIndexOf(".");
        return getClass().toString().substring(pos + 1);
    }

    public String getValue() {
        return value;
    }

    public void setValue(String v) {
        value = v;
    }

    static void setEnvironment(Environment e) {
        env = e;
    }

    static void printTree(String msg, Instruction instruction) {
        TreeIterator it = new TreeIterator(instruction);
        PrintVisitor visitor = new PrintVisitor();
        Instruction instr;
        while (it.hasNext()) {
            instr = it.next();
            instr.accept(visitor);
            System.out.println(msg + ": " + instr.getType());
        }
    }

    public void accept(Visitor v) {
        v.visit(this);
    }

    static Instruction parse() {
        return null;
    }

    Number eval() {
        return 0;
    }
}

class StackEntry {

    public Instruction instr;
    public int pos;

    public StackEntry(Instruction i, int p) {
        instr = i;
        pos = p;
    }
}
