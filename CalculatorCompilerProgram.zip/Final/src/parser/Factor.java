/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import scanner.*;

/**
 *
 * @author morell
 */
public class Factor extends Instruction {

    boolean parenthesized = false;
    boolean negative = false;

    Factor() {
        value = "Factor";
    }

    public Factor(Instruction instr) {
        il.add(instr);
    }

    public void accept(Visitor v) {
        v.visit(this);
    }

    static Factor parse() {
        Token t = scanner.getCurrentToken();
        BaseToken base = t.getBase();
        boolean negative = false;
        while (base instanceof MinusToken || base instanceof PlusToken) {
            if (t.getBase() instanceof MinusToken) {
                negative = !negative;
            }
            t = scanner.get();
            base = t.getBase();
        }
        Factor factor = new Factor();
        if (negative) {
            factor.negative = true;
        }
        if (base instanceof LParenToken) {
            factor.parenthesized = true;

            verify(simpleTokenFactory.createToken("("));
            Expression exp = Expression.parse();
            base = scanner.getCurrentToken().getBase();
            if (!(base instanceof RParenToken)) {
                System.err.println("Expected ')', found" + t);
                System.exit(1);
            } else {
                factor.add(exp);
            }
            verify(simpleTokenFactory.createToken(")")); // toos the ) 
        } else if (t.getBase() instanceof NumberToken) {
            No no = No.parse();
            factor.add(no);
        } else if (base instanceof IdToken) {
            factor.add(t);
            scanner.get();
        }
        return factor;
    }

    Number eval() {
        Instruction instr = il.get(1-1);
        double n;
        double coefficient = negative ? -1 : 1;
                
        if (instr instanceof Token) {
            n = ((Token) instr).eval().doubleValue();
        } else if (instr instanceof No) {
            n = ((No) instr).eval().doubleValue();
        } else {
            n = ((Expression) instr).eval().doubleValue();

        }
        return coefficient * n;
    }
}
