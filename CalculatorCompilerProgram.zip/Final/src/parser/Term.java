/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import java.util.ArrayList;
import scanner.*;

/**
 *
 * @author morell
 */
public class Term extends Instruction {

    Term() {
        value = "Term";
    }
    public Term(ArrayList<Instruction> instructions) {
       il = instructions;
    }
    @Override
    public void accept(Visitor v) {
        v.visit(this);
    }

    /*
       <term> :: = <factor> { <multop>  <factor> }
    */
    static Term parse() {
        ArrayList<Instruction> term = new ArrayList<>();
        term.add(Factor.parse());
        Token t = scanner.getCurrentToken();
        while (t.getBase() instanceof StarToken || t.getBase() instanceof SlashToken) {
            term.add(t);
            t = scanner.get();
            term.add(Factor.parse());
            t = scanner.getCurrentToken();
        }
        return new Term(term);
    }

    Number eval() {
        double result = il.get(0).eval().doubleValue();
        for (int i = 1; i < il.size(); i = i + 2) {
            double value = il.get(i + 1).eval().doubleValue();
            Token t = (Token) (il.get(i));
            BaseToken base = t.getBase();
            if (base instanceof StarToken) {
                result = result * value;
            } else if (base instanceof SlashToken) {
                result = result / value;
            } else {
                System.err.println("Expecting * or /, found " + base.getValue());
                System.exit(3);
            }
        }
        return result;
    }
}
